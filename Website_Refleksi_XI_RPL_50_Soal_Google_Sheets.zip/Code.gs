const SPREADSHEET_ID = "TEMPEL_ID_SPREADSHEET_DI_SINI";
const RESULT_HEADERS = ["TIMESTAMP","SUBMISSION_ID","ID_UJIAN","NAMA","KELAS","NOMOR_ABSEN","WORD_BENAR","EXCEL_BENAR","BASIS_DATA_BENAR","TOTAL_BENAR","TOTAL_SALAH","TOTAL_KOSONG","NILAI_AKHIR","KATEGORI","DURASI_DETIK","STATUS_UJIAN"];
const ANSWER_HEADERS = ["TIMESTAMP","SUBMISSION_ID","ID_UJIAN","NAMA","KELAS","NOMOR_ABSEN","NOMOR_SOAL","MATERI","LEVEL","PERTANYAAN","JAWABAN_SISWA","KUNCI_JAWABAN","STATUS_JAWABAN"];

function setupSheets(){
  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureSheet_(ss,"RESULTS",RESULT_HEADERS);
  ensureSheet_(ss,"ANSWERS",ANSWER_HEADERS);
}
function ensureSheet_(ss,name,headers){
  let sh=ss.getSheetByName(name);
  if(!sh) sh=ss.insertSheet(name);
  if(sh.getLastRow()===0){
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
    sh.getRange(1,1,1,headers.length).setFontWeight("bold");
    sh.autoResizeColumns(1,headers.length);
  }
}
function doGet(){
  return ContentService.createTextOutput("API refleksi XI RPL aktif.");
}
function doPost(e){
  const lock=LockService.getScriptLock();
  try{
    if(!e || !e.postData || !e.postData.contents) throw new Error("Payload kosong.");
    const p=JSON.parse(e.postData.contents);
    validate_(p);
    lock.waitLock(20000);
    try{
      const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
      const rs=ss.getSheetByName("RESULTS"), as=ss.getSheetByName("ANSWERS");
      if(!rs || !as) throw new Error("Jalankan setupSheets() terlebih dahulu.");
      const sid=String(p.submissionId);
      if(rs.getLastRow()>1){
        const found=rs.getRange(2,2,rs.getLastRow()-1,1).createTextFinder(sid).matchEntireCell(true).findNext();
        if(found) return output_({ok:true,duplicate:true});
      }
      const s=p.student,r=p.result,now=new Date();
      rs.appendRow([now,sid,String(p.examId),safe_(s.name),safe_(s.className),safe_(s.number),
        Number(r.wordCorrect),Number(r.excelCorrect),Number(r.databaseCorrect),Number(r.correct),
        Number(r.wrong),Number(r.blank),Number(r.score),safe_(r.category),Number(r.durationSeconds),safe_(r.status)]);
      const rows=p.answers.map(a=>[now,sid,String(p.examId),safe_(s.name),safe_(s.className),safe_(s.number),
        Number(a.questionNumber),safe_(a.section),safe_(a.level),safe_(a.question),safe_(a.studentAnswer),
        safe_(a.correctAnswer),a.isCorrect?"BENAR":(a.studentAnswer?"SALAH":"KOSONG")]);
      if(rows.length) as.getRange(as.getLastRow()+1,1,rows.length,ANSWER_HEADERS.length).setValues(rows);
      return output_({ok:true,saved:true});
    }finally{lock.releaseLock();}
  }catch(err){console.error(err);return output_({ok:false,error:String(err.message||err)});}
}
function validate_(p){
  if(p.action!=="saveResult" || !p.submissionId || !p.examId) throw new Error("Identitas pengiriman tidak valid.");
  if(!p.student || !p.result || !Array.isArray(p.answers)) throw new Error("Struktur data tidak valid.");
  if(!String(p.student.name||"").trim() || !String(p.student.className||"").trim() || !String(p.student.number||"").trim()) throw new Error("Identitas peserta belum lengkap.");
  if(p.answers.length!==50) throw new Error("Jumlah jawaban harus 50.");
  const r=p.result;
  ["wordCorrect","excelCorrect","databaseCorrect","correct","wrong","blank","score","durationSeconds"].forEach(k=>{if(!Number.isFinite(Number(r[k]))) throw new Error("Nilai tidak valid: "+k);});
  if(Number(r.score)<0 || Number(r.score)>100) throw new Error("Nilai di luar rentang.");
}
function safe_(v){
  const s=String(v==null?"":v).slice(0,5000);
  return /^[=+\-@]/.test(s)?"'"+s:s;
}
function output_(obj){return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);}
